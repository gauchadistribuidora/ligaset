"use client";

import { useState, useTransition } from "react";
import { Avatar } from "@/components/ui";
import { brl, PAYMENT_LABEL, PAYMENT_STYLE } from "@/lib/format";
import {
  setPaymentStatus,
  updatePayment,
  deletePayment,
} from "@/app/actions/payments";

export default function PaymentRow({
  groupId,
  payment,
  canManage,
}: {
  groupId: string;
  payment: any;
  canManage: boolean;
}) {
  const [pending, start] = useTransition();
  const [editing, setEditing] = useState(false);
  const [amount, setAmount] = useState<string>(String(payment.amount ?? 0));
  const [due, setDue] = useState<string>(payment.due_date ?? "");

  const m = payment.member;
  const name = m?.name || m?.profile?.full_name || "Jogador";
  const avatar = m?.profile?.avatar_url;

  function save() {
    start(async () => {
      await updatePayment(groupId, payment.id, {
        amount: Number(amount || 0),
        due_date: due || null,
      });
      setEditing(false);
    });
  }

  return (
    <div className="px-4 py-3">
      <div className="flex items-center gap-3">
        <Avatar name={name} url={avatar} size={36} />
        <div className="min-w-0 flex-1">
          <p className="truncate font-semibold">{name}</p>
          <p className="text-xs text-slate-400">{brl(Number(payment.amount))}</p>
        </div>

        {canManage ? (
          <>
            <select
              defaultValue={payment.status}
              disabled={pending}
              onChange={(e) =>
                start(async () => {
                  await setPaymentStatus(groupId, payment.id, e.target.value);
                })
              }
              className={`rounded-lg border-0 px-2 py-1.5 text-xs font-semibold ${PAYMENT_STYLE[payment.status]}`}
            >
              <option value="pending">Pendente</option>
              <option value="paid">Pago</option>
              <option value="overdue">Vencido</option>
              <option value="exempt">Isento</option>
            </select>
            <button
              onClick={() => setEditing((v) => !v)}
              className="ml-1 rounded-lg px-2 py-1 text-xs text-slate-500"
              aria-label="Editar"
            >
              ✎
            </button>
          </>
        ) : (
          <span className={`chip ${PAYMENT_STYLE[payment.status]}`}>
            {PAYMENT_LABEL[payment.status]}
          </span>
        )}
      </div>

      {canManage && editing && (
        <div className="mt-3 space-y-2 border-t border-slate-100 pt-3">
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="label !mb-1 text-xs">Valor (R$)</label>
              <input
                type="number"
                step="0.01"
                min={0}
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="input !py-2"
              />
            </div>
            <div>
              <label className="label !mb-1 text-xs">Vencimento</label>
              <input
                type="date"
                value={due}
                onChange={(e) => setDue(e.target.value)}
                className="input !py-2"
              />
            </div>
          </div>
          <div className="flex gap-2">
            <button onClick={save} disabled={pending} className="btn-primary flex-1 !py-2 text-sm">
              {pending ? "Salvando..." : "Salvar"}
            </button>
            <button
              onClick={() => {
                if (confirm("Excluir esta cobrança?"))
                  start(() => deletePayment(groupId, payment.id));
              }}
              disabled={pending}
              className="btn-danger !py-2 text-sm"
            >
              Excluir
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
